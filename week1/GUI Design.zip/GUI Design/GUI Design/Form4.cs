﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Design
{
    public partial class Form4 : Form
    {
        double num = 0.0d;
        String op = "";
        String mode = "general";
        public Form4()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txt_screen.Enabled)
            {
                power(false);
                btn_on.Text = "ON";
            }
            else
            {
                power(true);
                btn_on.Text = "OFF";
            }
        }
        private void power(Boolean status)
        {
            btn_1.Enabled = status;
            btn_2.Enabled = status;
            btn_3.Enabled = status;
            btn_4.Enabled = status;
            btn_5.Enabled = status;
            btn_6.Enabled = status;
            btn_7.Enabled = status;
            btn_8.Enabled = status;
            btn_9.Enabled = status;
            btn_0.Enabled = status;
            btn_00.Enabled = status;
            btn_add.Enabled = status;
            btn_sub.Enabled = status;
            btn_mul.Enabled = status;
            btn_modulo.Enabled = status;
            btn_decimal.Enabled = status;
            btn_divide.Enabled = status;
            btn_equal.Enabled = status;
            btn_clear.Enabled = status;
            txt_screen.Enabled = status;
            btn_factorial.Enabled = status;
            btn_hex.Enabled = status;
            btn_oct.Enabled = status;
            btn_binary.Enabled = status;
            btn_log.Enabled = status;
            clear_all();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clear_all();
        }

        private void clear_all()
        {
            txt_screen.Text = "0";
            num = 0.0d;
            op = "";
            btn_decimal.Enabled = true;
        }
        private void clear_screen()
        {
            txt_screen.Text = "";
        }
        private void btn_2_Click(object sender, EventArgs e)
        {
            if(op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "2";
            }
            else
                txt_screen.Text += 2;
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if(mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "1";
            }
            else
                txt_screen.Text += 1;
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "3";
            }
            else
                txt_screen.Text += 3;
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "4";
            }
            else
                txt_screen.Text += 4;
        }

        private void btn_00_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                txt_screen.Text = "";
                txt_screen.Text = "00";
            }
            else
                txt_screen.Text += "00";
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "5";
            }
            else
                txt_screen.Text += 5;
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "6";
            }
            else
                txt_screen.Text += 6;
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "7";
            }
            else
                txt_screen.Text += 7;
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "8";
            }
            else
                txt_screen.Text += 8;
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "9";
            }
            else
                txt_screen.Text += 9;
        }

        private void btn_0_Click(object sender, EventArgs e)
        {
            if (op == "" && txt_screen.Text == "0")
            {
                clear_screen();
            }
            if (mode == "programmer")
            {
                mode = "general";
                txt_screen.Text = "0";
            }
            else
                txt_screen.Text += 0;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            power(false);
        }

        private void btn_decimal_Click(object sender, EventArgs e)
        {
            txt_screen.Text += ".";
            btn_decimal.Enabled = false;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            
                select_op();
           
            op = "+";
            mode = "general";
        }
        private void select_op()
        {
            switch (op)
            {
                case "+":
                    num += Double.Parse(txt_screen.Text);
                    break;
                case "-":
                    num -= Double.Parse(txt_screen.Text);
                    break;
                case "/":
                    num /= Double.Parse(txt_screen.Text);
                    break;
                case "%":
                    num %= Double.Parse(txt_screen.Text);
                    break;
                case "*":
                    num *= Double.Parse(txt_screen.Text);
                    break;
                default:
                    if (txt_screen.Text != "")
                        num = Convert.ToDouble(txt_screen.Text);
                    else
                        num = 0d;
                    break;
            }
            txt_screen.Text = "";
            btn_decimal.Enabled = true;
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            
                select_op();
            
            op = "-";
            mode = "general";
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
           
                
                select_op();
            
            op = "/";
            mode = "general";
        }

        private void btn_mul_Click(object sender, EventArgs e)
        {
           
           select_op();
            
            op = "*";
            mode = "general";

        }

        private void btn_modulo_Click(object sender, EventArgs e)
        {
            select_op();
            op = "%";
            mode = "general";
        }

        private void btn_equal_Click(object sender, EventArgs e)
        {
            select_op();
            txt_screen.Text = num.ToString();
            op = "";
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            long n;
            long binaryNumber = 0;
            long remainder, i = 1;

            n = (long)Double.Parse(txt_screen.Text);
            while (n != 0)
            {
                remainder = n % 2;
                n /= 2;
                binaryNumber += remainder * i;
                i *= 10;
            }
            txt_screen.Text = binaryNumber.ToString();
            mode = "programmer";
            btn_decimal.Enabled = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            long result = 1;
            long numFact;
            numFact = (long)Double.Parse(txt_screen.Text);
            do
            {
                result *= numFact;
                numFact--;
            }
            while (numFact > 0);
            num = (Double)result;
            txt_screen.Text = result.ToString();
            mode = "programmer";
            btn_decimal.Enabled = true;
        }

        private void btn_dec_Click(object sender, EventArgs e)
        {
            txt_screen.Text = Math.Log(Double.Parse(txt_screen.Text)).ToString();
            mode = "programmer";
            btn_decimal.Enabled = true;
        }

        private void btn_hex_Click(object sender, EventArgs e)
        {
            long quotient;
            long temp;
            String hexadecimalNumber = "";

            quotient = (long)Double.Parse(txt_screen.Text);

            while (quotient != 0)
            {
                temp = quotient % 16;

                if (temp < 10)
                    temp = temp + 48;
                else
                    temp = temp + 55;

                hexadecimalNumber += (char)temp;
                quotient = quotient / 16;
            }
            txt_screen.Text = new String(hexadecimalNumber.ToCharArray().Reverse().ToArray());
           
            mode = "programmer";
            btn_decimal.Enabled = true;
        }

        private void btn_oct_Click(object sender, EventArgs e)
        {
            long octalNumber = 0, i = 1;
            long decimalNumber;
            decimalNumber = (long)Double.Parse(txt_screen.Text);
            while (decimalNumber != 0)
            {
                octalNumber += (decimalNumber % 8) * i;
                decimalNumber /= 8;
                i *= 10;
            }
            txt_screen.Text = octalNumber.ToString();
            mode = "programmer";
            btn_decimal.Enabled = true;
        }
    }
}
