﻿namespace lecture2
{
    partial class lb1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_1 = new System.Windows.Forms.ListBox();
            this.lb2 = new System.Windows.Forms.ListBox();
            this.lb3 = new System.Windows.Forms.ListBox();
            this.lb4 = new System.Windows.Forms.ListBox();
            this.lb5 = new System.Windows.Forms.ListBox();
            this.lb6 = new System.Windows.Forms.ListBox();
            this.lb7 = new System.Windows.Forms.ListBox();
            this.lb8 = new System.Windows.Forms.ListBox();
            this.lb9 = new System.Windows.Forms.ListBox();
            this.lb10 = new System.Windows.Forms.ListBox();
            this.lb11 = new System.Windows.Forms.ListBox();
            this.btn_start = new System.Windows.Forms.Button();
            this.col1 = new System.Windows.Forms.Label();
            this.col2 = new System.Windows.Forms.Label();
            this.col3 = new System.Windows.Forms.Label();
            this.col4 = new System.Windows.Forms.Label();
            this.col5 = new System.Windows.Forms.Label();
            this.col1_1 = new System.Windows.Forms.Label();
            this.col1_2 = new System.Windows.Forms.Label();
            this.col1_3 = new System.Windows.Forms.Label();
            this.col1_4 = new System.Windows.Forms.Label();
            this.col1_5 = new System.Windows.Forms.Label();
            this.col1_6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_1
            // 
            this.lb_1.FormattingEnabled = true;
            this.lb_1.ItemHeight = 16;
            this.lb_1.Items.AddRange(new object[] {
            "a",
            "f",
            "k",
            "p",
            "u",
            "z"});
            this.lb_1.Location = new System.Drawing.Point(43, 54);
            this.lb_1.Name = "lb_1";
            this.lb_1.Size = new System.Drawing.Size(18, 100);
            this.lb_1.TabIndex = 0;
            // 
            // lb2
            // 
            this.lb2.FormattingEnabled = true;
            this.lb2.ItemHeight = 16;
            this.lb2.Items.AddRange(new object[] {
            "b",
            "g",
            "l",
            "q",
            "v"});
            this.lb2.Location = new System.Drawing.Point(98, 54);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(20, 100);
            this.lb2.TabIndex = 1;
            this.lb2.SelectedIndexChanged += new System.EventHandler(this.lb2_SelectedIndexChanged);
            // 
            // lb3
            // 
            this.lb3.FormattingEnabled = true;
            this.lb3.ItemHeight = 16;
            this.lb3.Items.AddRange(new object[] {
            "c",
            "h",
            "m",
            "r",
            "w"});
            this.lb3.Location = new System.Drawing.Point(161, 54);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(19, 100);
            this.lb3.TabIndex = 2;
            // 
            // lb4
            // 
            this.lb4.FormattingEnabled = true;
            this.lb4.ItemHeight = 16;
            this.lb4.Items.AddRange(new object[] {
            "d",
            "i",
            "n",
            "s",
            "x"});
            this.lb4.Location = new System.Drawing.Point(225, 54);
            this.lb4.Name = "lb4";
            this.lb4.Size = new System.Drawing.Size(20, 100);
            this.lb4.TabIndex = 3;
            // 
            // lb5
            // 
            this.lb5.FormattingEnabled = true;
            this.lb5.ItemHeight = 16;
            this.lb5.Items.AddRange(new object[] {
            "e",
            "j",
            "o",
            "t",
            "y"});
            this.lb5.Location = new System.Drawing.Point(292, 54);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(19, 100);
            this.lb5.TabIndex = 4;
            this.lb5.SelectedIndexChanged += new System.EventHandler(this.lb5_SelectedIndexChanged);
            // 
            // lb6
            // 
            this.lb6.FormattingEnabled = true;
            this.lb6.ItemHeight = 16;
            this.lb6.Location = new System.Drawing.Point(44, 54);
            this.lb6.Name = "lb6";
            this.lb6.Size = new System.Drawing.Size(19, 100);
            this.lb6.TabIndex = 5;
            this.lb6.Visible = false;
            this.lb6.SelectedIndexChanged += new System.EventHandler(this.lb6_SelectedIndexChanged);
            // 
            // lb7
            // 
            this.lb7.FormattingEnabled = true;
            this.lb7.ItemHeight = 16;
            this.lb7.Location = new System.Drawing.Point(99, 54);
            this.lb7.Name = "lb7";
            this.lb7.Size = new System.Drawing.Size(19, 100);
            this.lb7.TabIndex = 6;
            this.lb7.Visible = false;
            // 
            // lb8
            // 
            this.lb8.FormattingEnabled = true;
            this.lb8.ItemHeight = 16;
            this.lb8.Location = new System.Drawing.Point(162, 54);
            this.lb8.Name = "lb8";
            this.lb8.Size = new System.Drawing.Size(19, 100);
            this.lb8.TabIndex = 7;
            this.lb8.Visible = false;
            // 
            // lb9
            // 
            this.lb9.FormattingEnabled = true;
            this.lb9.ItemHeight = 16;
            this.lb9.Location = new System.Drawing.Point(219, 54);
            this.lb9.Name = "lb9";
            this.lb9.Size = new System.Drawing.Size(19, 100);
            this.lb9.TabIndex = 8;
            this.lb9.Visible = false;
            // 
            // lb10
            // 
            this.lb10.FormattingEnabled = true;
            this.lb10.ItemHeight = 16;
            this.lb10.Location = new System.Drawing.Point(293, 54);
            this.lb10.Name = "lb10";
            this.lb10.Size = new System.Drawing.Size(19, 100);
            this.lb10.TabIndex = 9;
            this.lb10.Visible = false;
            // 
            // lb11
            // 
            this.lb11.FormattingEnabled = true;
            this.lb11.ItemHeight = 16;
            this.lb11.Location = new System.Drawing.Point(350, 54);
            this.lb11.Name = "lb11";
            this.lb11.Size = new System.Drawing.Size(19, 100);
            this.lb11.TabIndex = 10;
            this.lb11.Visible = false;
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(157, 194);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(75, 23);
            this.btn_start.TabIndex = 11;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // col1
            // 
            this.col1.AutoSize = true;
            this.col1.Location = new System.Drawing.Point(38, 33);
            this.col1.Name = "col1";
            this.col1.Size = new System.Drawing.Size(16, 17);
            this.col1.TabIndex = 12;
            this.col1.Text = "1";
            // 
            // col2
            // 
            this.col2.AutoSize = true;
            this.col2.Location = new System.Drawing.Point(95, 34);
            this.col2.Name = "col2";
            this.col2.Size = new System.Drawing.Size(16, 17);
            this.col2.TabIndex = 13;
            this.col2.Text = "2";
            // 
            // col3
            // 
            this.col3.AutoSize = true;
            this.col3.Location = new System.Drawing.Point(158, 34);
            this.col3.Name = "col3";
            this.col3.Size = new System.Drawing.Size(16, 17);
            this.col3.TabIndex = 14;
            this.col3.Text = "3";
            // 
            // col4
            // 
            this.col4.AutoSize = true;
            this.col4.Location = new System.Drawing.Point(222, 33);
            this.col4.Name = "col4";
            this.col4.Size = new System.Drawing.Size(16, 17);
            this.col4.TabIndex = 15;
            this.col4.Text = "4";
            // 
            // col5
            // 
            this.col5.AutoSize = true;
            this.col5.Location = new System.Drawing.Point(289, 33);
            this.col5.Name = "col5";
            this.col5.Size = new System.Drawing.Size(16, 17);
            this.col5.TabIndex = 16;
            this.col5.Text = "5";
            // 
            // col1_1
            // 
            this.col1_1.AutoSize = true;
            this.col1_1.Location = new System.Drawing.Point(41, 33);
            this.col1_1.Name = "col1_1";
            this.col1_1.Size = new System.Drawing.Size(16, 17);
            this.col1_1.TabIndex = 17;
            this.col1_1.Text = "1";
            this.col1_1.Visible = false;
            // 
            // col1_2
            // 
            this.col1_2.AutoSize = true;
            this.col1_2.Location = new System.Drawing.Point(96, 33);
            this.col1_2.Name = "col1_2";
            this.col1_2.Size = new System.Drawing.Size(16, 17);
            this.col1_2.TabIndex = 18;
            this.col1_2.Text = "2";
            this.col1_2.Visible = false;
            // 
            // col1_3
            // 
            this.col1_3.AutoSize = true;
            this.col1_3.Location = new System.Drawing.Point(159, 33);
            this.col1_3.Name = "col1_3";
            this.col1_3.Size = new System.Drawing.Size(16, 17);
            this.col1_3.TabIndex = 19;
            this.col1_3.Text = "3";
            this.col1_3.Visible = false;
            // 
            // col1_4
            // 
            this.col1_4.AutoSize = true;
            this.col1_4.Location = new System.Drawing.Point(216, 33);
            this.col1_4.Name = "col1_4";
            this.col1_4.Size = new System.Drawing.Size(16, 17);
            this.col1_4.TabIndex = 20;
            this.col1_4.Text = "4";
            this.col1_4.Visible = false;
            // 
            // col1_5
            // 
            this.col1_5.AutoSize = true;
            this.col1_5.Location = new System.Drawing.Point(290, 34);
            this.col1_5.Name = "col1_5";
            this.col1_5.Size = new System.Drawing.Size(16, 17);
            this.col1_5.TabIndex = 21;
            this.col1_5.Text = "5";
            this.col1_5.Visible = false;
            // 
            // col1_6
            // 
            this.col1_6.AutoSize = true;
            this.col1_6.Location = new System.Drawing.Point(347, 33);
            this.col1_6.Name = "col1_6";
            this.col1_6.Size = new System.Drawing.Size(16, 17);
            this.col1_6.TabIndex = 22;
            this.col1_6.Text = "6";
            this.col1_6.Visible = false;
            // 
            // lb1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(402, 235);
            this.Controls.Add(this.col1_6);
            this.Controls.Add(this.col1_5);
            this.Controls.Add(this.col1_4);
            this.Controls.Add(this.col1_3);
            this.Controls.Add(this.col1_2);
            this.Controls.Add(this.col1_1);
            this.Controls.Add(this.col5);
            this.Controls.Add(this.col4);
            this.Controls.Add(this.col3);
            this.Controls.Add(this.col2);
            this.Controls.Add(this.col1);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.lb11);
            this.Controls.Add(this.lb10);
            this.Controls.Add(this.lb9);
            this.Controls.Add(this.lb8);
            this.Controls.Add(this.lb7);
            this.Controls.Add(this.lb6);
            this.Controls.Add(this.lb5);
            this.Controls.Add(this.lb4);
            this.Controls.Add(this.lb3);
            this.Controls.Add(this.lb2);
            this.Controls.Add(this.lb_1);
            this.Name = "lb1";
            this.Text = "listplayname";
            this.Load += new System.EventHandler(this.lb1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_1;
        private System.Windows.Forms.ListBox lb2;
        private System.Windows.Forms.ListBox lb3;
        private System.Windows.Forms.ListBox lb4;
        private System.Windows.Forms.ListBox lb5;
        private System.Windows.Forms.ListBox lb6;
        private System.Windows.Forms.ListBox lb7;
        private System.Windows.Forms.ListBox lb8;
        private System.Windows.Forms.ListBox lb9;
        private System.Windows.Forms.ListBox lb10;
        private System.Windows.Forms.ListBox lb11;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Label col1;
        private System.Windows.Forms.Label col2;
        private System.Windows.Forms.Label col3;
        private System.Windows.Forms.Label col4;
        private System.Windows.Forms.Label col5;
        private System.Windows.Forms.Label col1_1;
        private System.Windows.Forms.Label col1_2;
        private System.Windows.Forms.Label col1_3;
        private System.Windows.Forms.Label col1_4;
        private System.Windows.Forms.Label col1_5;
        private System.Windows.Forms.Label col1_6;
    }
}