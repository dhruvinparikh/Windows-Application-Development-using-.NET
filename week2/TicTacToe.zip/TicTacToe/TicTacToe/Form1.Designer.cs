﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_1 = new System.Windows.Forms.Label();
            this.lbl_2 = new System.Windows.Forms.Label();
            this.lbl_3 = new System.Windows.Forms.Label();
            this.lbl_4 = new System.Windows.Forms.Label();
            this.lbl_5 = new System.Windows.Forms.Label();
            this.lbl_6 = new System.Windows.Forms.Label();
            this.lbl_7 = new System.Windows.Forms.Label();
            this.lbl_8 = new System.Windows.Forms.Label();
            this.lbl_9 = new System.Windows.Forms.Label();
            this.btn_play = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(129, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "TIC TAC TOE";
            // 
            // lbl_1
            // 
            this.lbl_1.AutoSize = true;
            this.lbl_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_1.Location = new System.Drawing.Point(51, 135);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Size = new System.Drawing.Size(39, 19);
            this.lbl_1.TabIndex = 1;
            this.lbl_1.Text = "Click";
            this.lbl_1.Click += new System.EventHandler(this.lbl_1_Click);
            this.lbl_1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // lbl_2
            // 
            this.lbl_2.AutoSize = true;
            this.lbl_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_2.Location = new System.Drawing.Point(152, 135);
            this.lbl_2.Name = "lbl_2";
            this.lbl_2.Size = new System.Drawing.Size(39, 19);
            this.lbl_2.TabIndex = 2;
            this.lbl_2.Text = "Click";
            this.lbl_2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // lbl_3
            // 
            this.lbl_3.AutoSize = true;
            this.lbl_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_3.Location = new System.Drawing.Point(261, 135);
            this.lbl_3.Name = "lbl_3";
            this.lbl_3.Size = new System.Drawing.Size(39, 19);
            this.lbl_3.TabIndex = 3;
            this.lbl_3.Text = "Click";
            this.lbl_3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // lbl_4
            // 
            this.lbl_4.AutoSize = true;
            this.lbl_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_4.Location = new System.Drawing.Point(51, 177);
            this.lbl_4.Name = "lbl_4";
            this.lbl_4.Size = new System.Drawing.Size(39, 19);
            this.lbl_4.TabIndex = 4;
            this.lbl_4.Text = "Click";
            this.lbl_4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // lbl_5
            // 
            this.lbl_5.AutoSize = true;
            this.lbl_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_5.Location = new System.Drawing.Point(152, 177);
            this.lbl_5.Name = "lbl_5";
            this.lbl_5.Size = new System.Drawing.Size(39, 19);
            this.lbl_5.TabIndex = 5;
            this.lbl_5.Text = "Click";
            this.lbl_5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // lbl_6
            // 
            this.lbl_6.AutoSize = true;
            this.lbl_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_6.Location = new System.Drawing.Point(261, 177);
            this.lbl_6.Name = "lbl_6";
            this.lbl_6.Size = new System.Drawing.Size(39, 19);
            this.lbl_6.TabIndex = 6;
            this.lbl_6.Text = "Click";
            this.lbl_6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // lbl_7
            // 
            this.lbl_7.AutoSize = true;
            this.lbl_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_7.Location = new System.Drawing.Point(51, 223);
            this.lbl_7.Name = "lbl_7";
            this.lbl_7.Size = new System.Drawing.Size(39, 19);
            this.lbl_7.TabIndex = 7;
            this.lbl_7.Text = "Click";
            this.lbl_7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // lbl_8
            // 
            this.lbl_8.AutoSize = true;
            this.lbl_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_8.Location = new System.Drawing.Point(152, 223);
            this.lbl_8.Name = "lbl_8";
            this.lbl_8.Size = new System.Drawing.Size(39, 19);
            this.lbl_8.TabIndex = 8;
            this.lbl_8.Text = "Click";
            this.lbl_8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // lbl_9
            // 
            this.lbl_9.AutoSize = true;
            this.lbl_9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_9.Location = new System.Drawing.Point(261, 223);
            this.lbl_9.Name = "lbl_9";
            this.lbl_9.Size = new System.Drawing.Size(39, 19);
            this.lbl_9.TabIndex = 9;
            this.lbl_9.Text = "Click";
            this.lbl_9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TicTacToe_ClickEvent);
            // 
            // btn_play
            // 
            this.btn_play.Location = new System.Drawing.Point(137, 76);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(75, 23);
            this.btn_play.TabIndex = 10;
            this.btn_play.Text = "PLAY";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 266);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.lbl_9);
            this.Controls.Add(this.lbl_8);
            this.Controls.Add(this.lbl_7);
            this.Controls.Add(this.lbl_6);
            this.Controls.Add(this.lbl_5);
            this.Controls.Add(this.lbl_4);
            this.Controls.Add(this.lbl_3);
            this.Controls.Add(this.lbl_2);
            this.Controls.Add(this.lbl_1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.Label lbl_2;
        private System.Windows.Forms.Label lbl_3;
        private System.Windows.Forms.Label lbl_4;
        private System.Windows.Forms.Label lbl_5;
        private System.Windows.Forms.Label lbl_6;
        private System.Windows.Forms.Label lbl_7;
        private System.Windows.Forms.Label lbl_8;
        private System.Windows.Forms.Label lbl_9;
        private System.Windows.Forms.Button btn_play;
    }
}

