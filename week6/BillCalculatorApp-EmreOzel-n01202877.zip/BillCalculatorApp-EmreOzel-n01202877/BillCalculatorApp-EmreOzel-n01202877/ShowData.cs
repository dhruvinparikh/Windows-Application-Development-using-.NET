﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BillCalculatorApp_EmreOzel_n01202877
{
    public partial class ShowData : Form
    {

        SqlConnection con;
      
        int tNo;

        public ShowData()
        {
            InitializeComponent();
        }

        public ShowData(int tNo)
        {
            InitializeComponent();
            this.tNo = tNo;
        }


        private void ShowData_Load(object sender, EventArgs e)
        {
            //comboBox1.DataBindings.Add("SelectedValue", OrderDetails, "ItemID");
            fillCombobox();
            callData(tNo);

        }

        private void fillCombobox()
        {

            try
            {
                connect();
                SqlDataAdapter adapter = new SqlDataAdapter("Select distinct tNo from cust_transact", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "adapter");
                comboBox1.ValueMember = "tNo";
                comboBox1.DataSource = ds.Tables["adapter"];
                comboBox1.SelectedValue = tNo.ToString();
                close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot establish connection with the server.");
            }
        }

        private void callData(int tableNo)
        {
            try
            {
                connect();
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT tno ,cust_name ,item ,date_entry FROM [Restaurant].[dbo].[cust_transact] where tno = " + tableNo, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                //dataGridView1.DataBindingComplete();
                close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot open connection with the server.");
            }
        }

        private void connect()
        {
            try
            {
                con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Restaurant; Integrated Security = True");
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot connect to the server.");
            }
        }

        private void close()
        {
            con.Close();
        }

        private void item_changed_5(object sender, EventArgs e)
        {
            changed();
        }

        private void changed()
        {
            string item1 = comboBox1.SelectedValue.ToString();
            if (item1 != "")
            {
                int x = Int32.Parse(item1);
                callData(x);
            }
            

        }
    }
}

