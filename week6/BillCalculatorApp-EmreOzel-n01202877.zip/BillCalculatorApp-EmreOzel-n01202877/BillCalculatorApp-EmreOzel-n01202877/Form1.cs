﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BillCalculatorApp_EmreOzel_n01202877
{
    public partial class Form1 : Form
    {
        SqlConnection con;

        double subTotal = 0.0;
        double taxTotal = 0.0;
        double tax = .07;
        double total = 0;
        double price1 = 0;
        double price2 = 0;
        double price3 = 0;
        double price4 = 0;

        string item1;
        string item2;
        string item3;
        string item4;

        public Form1()
        {
            InitializeComponent();
          
            setComboboxes();
    
        }

        private void connect()
        {
            try
            {
                con = new SqlConnection("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = Restaurant; Integrated Security = True");
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot open the connection.");
            }
        }

        private void close()
        {
            con.Close();
        }

        private void setComboboxes()
        {
            try
            {
                callData(comboBox1, "Beverage");
                callData(comboBox2, "Appetizer");
                callData(comboBox3, "Main Course");
                callData(comboBox4, "Dessert");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot establish connection.");
            }
        }

        private void callData(ComboBox combobox, string type)
        {

            try
            {
                connect();
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT item FROM[Restaurant].[dbo].[menulist] where[category] = '" + type + "' ", con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "adapter");
                combobox.ValueMember = "item";
                combobox.DataSource = ds.Tables["adapter"];
                close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Cannot establish connection with the server.");
            }
        }
       

        public void billTotal(double price)
        {
            subTotal = price;
    
            textBox3.Text = subTotal.ToString("");
            taxTotal = subTotal * tax;
            textBox4.Text = taxTotal.ToString("");
            total = subTotal + taxTotal;
            textBox5.Text = total.ToString("");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {

            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            comboBox4.Text = "";
            textBox3.Text = "$0.00";
            textBox4.Text = "$0.00";
            textBox5.Text = "$0.00";
        }



     
        private void item_changed_1(object sender, EventArgs e)
        {

            price1 = item_changed(sender, e);
            ComboBox item_picker = (ComboBox)sender;
            item1 = item_picker.SelectedValue.ToString();
        }

        private void item_changed_2(object sender, EventArgs e)
        {
            price2 = item_changed(sender, e);
            ComboBox item_picker = (ComboBox)sender;
            item2 = item_picker.SelectedValue.ToString();
        }

        private void item_changed_3(object sender, EventArgs e)
        {
            price3 = item_changed(sender, e);
            ComboBox item_picker = (ComboBox)sender;
            item3 = item_picker.SelectedValue.ToString();
        }

        private void item_changed_4(object sender, EventArgs e)
        {
            price4 = item_changed(sender, e);
            ComboBox item_picker = (ComboBox)sender;
            item4 = item_picker.SelectedValue.ToString();
        }

        private double item_changed(object sender, EventArgs e)
        {
            connect();

            ComboBox item_picker = (ComboBox)sender;
            String item = item_picker.SelectedValue.ToString();
            SqlCommand cmd = new SqlCommand("Select price from menulist where item = '" + item + "'", con);
            SqlDataReader output = cmd.ExecuteReader();
            double p = 0;
            while (output.Read())
            {
               p  = output.GetDouble(0);
            }
            close();
            billTotal(price1 + price2 + price3 + price4);
            return p;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Table No is required.");
                return;
            }

            else { 
}
      
            insert(item1);
            insert(item2);
            insert(item3);
            insert(item4);

            int x = Int32.Parse(textBox1.Text);
            ShowData sd = new ShowData(x);
            sd.Show();
        }

        private void insert(String item)
        {
            connect();
            SqlCommand cmd = new SqlCommand("insert into cust_transact (tno, cust_name, item, date_entry) values(@no,@custName,@item,@dateEntry)", con);
            cmd.Parameters.AddWithValue("@no", textBox1.Text);
            cmd.Parameters.AddWithValue("@custName", textBox2.Text);
            cmd.Parameters.AddWithValue("@item", item);
            cmd.Parameters.AddWithValue("@dateEntry", DateTime.Now);
            cmd.ExecuteNonQuery();
            close();
        }
    }
}
      
    

