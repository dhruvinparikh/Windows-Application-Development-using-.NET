﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void colorpicker(object sender, EventArgs e)
        {
            clearcolor();
            if(sender==redcolormenu)
            {
                label1.ForeColor = Color.Red;
                redcolormenu.Checked = true;
            }
            else if(sender==greencolormenu)
            {
                label1.ForeColor = Color.Green;
                greencolormenu.Checked = true;
            }
            else if(sender==bluecolormenu)
            {
                label1.ForeColor = Color.Blue;
                bluecolormenu.Checked = true;
            }
            else
            {
                label1.ForeColor = Color.Black;
            }
        }
        private void clearcolor()
        {
            redcolormenu.Checked = false;
            greencolormenu.Checked = false;
            bluecolormenu.Checked = false;
        }

        private void stylepicker(object sender, EventArgs e)
        {
            
            if(sender==arialfont)
            {
                styleclear();
                label1.Font = new Font("Arial", 14, label1.Font.Style);
                arialfont.Checked = true;
            }
            else if(sender==tnrfont)
            {
                styleclear();
                label1.Font = new Font("Times New Roman", 14, label1.Font.Style);
                tnrfont.Checked = true;
            }
            else if(sender==seriffont)
            {
                styleclear();
                label1.Font = new Font("Serif", 14, label1.Font.Style);
                seriffont.Checked = true;
            }
            else if(sender==boldstyle)
            {
                label1.Font = new Font(label1.Font, label1.Font.Style^FontStyle.Bold);
                boldstyle.Checked = true;
            }
            else if(sender==italicstyle)
            {
                label1.Font = new Font(label1.Font, label1.Font.Style ^ FontStyle.Italic);
                italicstyle.Checked = true;
            }
        }
        private void styleclear()
        {
            arialfont.Checked = false;
            tnrfont.Checked = false;
            seriffont.Checked = false;
        }

        private void openmenu_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\");
        }

        private void exitmenu_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exit(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
