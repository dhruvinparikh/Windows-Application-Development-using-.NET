﻿namespace Menus
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.FileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.openmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.exitmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.editmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.colorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redcolormenu = new System.Windows.Forms.ToolStripMenuItem();
            this.greencolormenu = new System.Windows.Forms.ToolStripMenuItem();
            this.bluecolormenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.styleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arialfont = new System.Windows.Forms.ToolStripMenuItem();
            this.tnrfont = new System.Windows.Forms.ToolStripMenuItem();
            this.seriffont = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.boldstyle = new System.Windows.Forms.ToolStripMenuItem();
            this.italicstyle = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileMenu,
            this.editmenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(654, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // FileMenu
            // 
            this.FileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openmenu,
            this.exitmenu});
            this.FileMenu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FileMenu.Name = "FileMenu";
            this.FileMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.FileMenu.Size = new System.Drawing.Size(53, 29);
            this.FileMenu.Text = "&File";
            // 
            // openmenu
            // 
            this.openmenu.Name = "openmenu";
            this.openmenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openmenu.Size = new System.Drawing.Size(227, 30);
            this.openmenu.Text = "&Open C:\\";
            this.openmenu.Click += new System.EventHandler(this.openmenu_Click);
            // 
            // exitmenu
            // 
            this.exitmenu.Name = "exitmenu";
            this.exitmenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.exitmenu.Size = new System.Drawing.Size(227, 30);
            this.exitmenu.Text = "E&xit";
            this.exitmenu.Click += new System.EventHandler(this.exitmenu_Click);
            // 
            // editmenu
            // 
            this.editmenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colorToolStripMenuItem,
            this.toolStripSeparator1,
            this.styleToolStripMenuItem});
            this.editmenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editmenu.Name = "editmenu";
            this.editmenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.E)));
            this.editmenu.Size = new System.Drawing.Size(48, 29);
            this.editmenu.Text = "&Edit";
            // 
            // colorToolStripMenuItem
            // 
            this.colorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.redcolormenu,
            this.greencolormenu,
            this.bluecolormenu});
            this.colorToolStripMenuItem.Name = "colorToolStripMenuItem";
            this.colorToolStripMenuItem.Size = new System.Drawing.Size(118, 26);
            this.colorToolStripMenuItem.Text = "Color";
            // 
            // redcolormenu
            // 
            this.redcolormenu.CheckOnClick = true;
            this.redcolormenu.Name = "redcolormenu";
            this.redcolormenu.Size = new System.Drawing.Size(122, 26);
            this.redcolormenu.Text = "Red";
            this.redcolormenu.Click += new System.EventHandler(this.colorpicker);
            // 
            // greencolormenu
            // 
            this.greencolormenu.CheckOnClick = true;
            this.greencolormenu.Name = "greencolormenu";
            this.greencolormenu.Size = new System.Drawing.Size(122, 26);
            this.greencolormenu.Text = "Green";
            this.greencolormenu.Click += new System.EventHandler(this.colorpicker);
            // 
            // bluecolormenu
            // 
            this.bluecolormenu.CheckOnClick = true;
            this.bluecolormenu.Name = "bluecolormenu";
            this.bluecolormenu.Size = new System.Drawing.Size(122, 26);
            this.bluecolormenu.Text = "Blue";
            this.bluecolormenu.Click += new System.EventHandler(this.colorpicker);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(115, 6);
            // 
            // styleToolStripMenuItem
            // 
            this.styleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arialfont,
            this.tnrfont,
            this.seriffont,
            this.toolStripMenuItem1,
            this.boldstyle,
            this.italicstyle});
            this.styleToolStripMenuItem.Name = "styleToolStripMenuItem";
            this.styleToolStripMenuItem.Size = new System.Drawing.Size(118, 26);
            this.styleToolStripMenuItem.Text = "Style";
            // 
            // arialfont
            // 
            this.arialfont.CheckOnClick = true;
            this.arialfont.Name = "arialfont";
            this.arialfont.Size = new System.Drawing.Size(204, 26);
            this.arialfont.Text = "Arial";
            this.arialfont.Click += new System.EventHandler(this.stylepicker);
            // 
            // tnrfont
            // 
            this.tnrfont.CheckOnClick = true;
            this.tnrfont.Name = "tnrfont";
            this.tnrfont.Size = new System.Drawing.Size(204, 26);
            this.tnrfont.Text = "Time New Roman";
            this.tnrfont.Click += new System.EventHandler(this.stylepicker);
            // 
            // seriffont
            // 
            this.seriffont.CheckOnClick = true;
            this.seriffont.Name = "seriffont";
            this.seriffont.Size = new System.Drawing.Size(204, 26);
            this.seriffont.Text = "Serif";
            this.seriffont.Click += new System.EventHandler(this.stylepicker);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(201, 6);
            // 
            // boldstyle
            // 
            this.boldstyle.CheckOnClick = true;
            this.boldstyle.Name = "boldstyle";
            this.boldstyle.Size = new System.Drawing.Size(204, 26);
            this.boldstyle.Text = "Bold";
            this.boldstyle.Click += new System.EventHandler(this.stylepicker);
            // 
            // italicstyle
            // 
            this.italicstyle.CheckOnClick = true;
            this.italicstyle.Name = "italicstyle";
            this.italicstyle.Size = new System.Drawing.Size(204, 26);
            this.italicstyle.Text = "Italics";
            this.italicstyle.Click += new System.EventHandler(this.stylepicker);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(183, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Testing style Execution";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 532);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.exit);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem FileMenu;
        private System.Windows.Forms.ToolStripMenuItem openmenu;
        private System.Windows.Forms.ToolStripMenuItem exitmenu;
        private System.Windows.Forms.ToolStripMenuItem editmenu;
        private System.Windows.Forms.ToolStripMenuItem colorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redcolormenu;
        private System.Windows.Forms.ToolStripMenuItem greencolormenu;
        private System.Windows.Forms.ToolStripMenuItem bluecolormenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem styleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arialfont;
        private System.Windows.Forms.ToolStripMenuItem tnrfont;
        private System.Windows.Forms.ToolStripMenuItem seriffont;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem boldstyle;
        private System.Windows.Forms.ToolStripMenuItem italicstyle;
        private System.Windows.Forms.Label label1;
    }
}

