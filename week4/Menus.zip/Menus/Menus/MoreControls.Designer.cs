﻿namespace Menus
{
    partial class MoreControls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MoreControls));
            this.linkhelp = new System.Windows.Forms.LinkLabel();
            this.backlink = new System.Windows.Forms.LinkLabel();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // linkhelp
            // 
            this.linkhelp.AutoSize = true;
            this.linkhelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkhelp.Location = new System.Drawing.Point(423, 417);
            this.linkhelp.Name = "linkhelp";
            this.linkhelp.Size = new System.Drawing.Size(148, 20);
            this.linkhelp.TabIndex = 0;
            this.linkhelp.TabStop = true;
            this.linkhelp.Text = "Visit Online for Help";
            this.linkhelp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.online_help);
            // 
            // backlink
            // 
            this.backlink.AutoSize = true;
            this.backlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backlink.Location = new System.Drawing.Point(427, 362);
            this.backlink.Name = "backlink";
            this.backlink.Size = new System.Drawing.Size(71, 20);
            this.backlink.TabIndex = 1;
            this.backlink.TabStop = true;
            this.backlink.Text = "Go Back";
            this.backlink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.back);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "a1.png");
            this.imageList1.Images.SetKeyName(1, "a2.png");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(195, 141);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(215, 135);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // MoreControls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 474);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.backlink);
            this.Controls.Add(this.linkhelp);
            this.Name = "MoreControls";
            this.Text = "MoreControls";
            this.Load += new System.EventHandler(this.MoreControls_Load);
            this.Click += new System.EventHandler(this.showpic);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel linkhelp;
        private System.Windows.Forms.LinkLabel backlink;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}