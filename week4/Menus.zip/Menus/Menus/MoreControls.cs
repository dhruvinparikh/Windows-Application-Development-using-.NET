﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menus
{
    public partial class MoreControls : Form
    {
        public MoreControls()
        {
            InitializeComponent();
        }

        private void online_help(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("notepad");

        }

        private void back(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 obj = new Form1();
            obj.Show();
            this.Hide();
        }

        private void MoreControls_Load(object sender, EventArgs e)
        {

        }

        private void showpic(object sender, EventArgs e)
        {
            foreach (Image i in imageList1.Images)
            {
                pictureBox1.Image = i;
                System.Threading.Thread.Sleep(2000);
                pictureBox1.Refresh();
            }
        }
    }
}
